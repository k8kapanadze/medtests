import { Question } from "./types";

/**
 * Parses raw text into medical questions based on:
 * //// - Question Start
 * /// - Incorrect answer
 * // - Correct answer
 */
export function parseQuestionsText(text: string, filename: string): Question[] {
  const questions: Question[] = [];
  const lines = text.split("\n");

  let currentQuestionText = "";
  let currentIncorrect: string[] = [];
  let currentCorrect: string[] = [];

  const pushCurrent = () => {
    if (currentQuestionText.trim()) {
      const id = Math.random().toString(36).substring(2, 11) + "-" + Date.now();
      const correct = currentCorrect.map(c => c.trim()).filter(Boolean);
      const incorrect = currentIncorrect.map(i => i.trim()).filter(Boolean);
      const textClean = currentQuestionText.trim();

      // Combine both options
      const options = [...correct, ...incorrect];

      questions.push({
        id,
        text: textClean,
        correctAnswers: correct,
        incorrectAnswers: incorrect,
        options,
        correctOptionText: correct[0] || "",
        sourceFile: filename,
      });
    }
    currentQuestionText = "";
    currentIncorrect = [];
    currentCorrect = [];
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    if (line.startsWith("////")) {
      pushCurrent();
      currentQuestionText = line.replace(/^\/\/\/\/\s*/, "").trim();
    } else if (line.startsWith("///")) {
      currentIncorrect.push(line.replace(/^\/\/\/\s*/, "").trim());
    } else if (line.startsWith("//")) {
      currentCorrect.push(line.replace(/^\/\/\s*/, "").trim());
    }
  }

  // Push final question
  pushCurrent();

  return questions;
}

/**
 * Standard robust Fisher-Yates shuffle
 */
export function shuffleArray<T>(array: T[]): T[] {
  const result = [...array];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const temp = result[i];
    result[i] = result[j];
    result[j] = temp;
  }
  return result;
}

/**
 * Prepares questions with Double Shuffle (shuffling questions + options)
 */
export function prepareQuestions(
  questions: Question[],
  shuffleQuestionsEnabled: boolean,
  shuffleOptionsEnabled: boolean
): Question[] {
  let processed = questions.map((q) => {
    let options = [...q.correctAnswers, ...q.incorrectAnswers];
    if (shuffleOptionsEnabled) {
      options = shuffleArray(options);
    }
    return {
      ...q,
      options,
    };
  });

  if (shuffleQuestionsEnabled) {
    processed = shuffleArray(processed);
  }

  return processed;
}

/**
 * Formats parsed questions back into the official text structure for download (.txt)
 */
export function exportMistakesToRawText(questions: Question[]): string {
  let output = "";
  questions.forEach((q) => {
    output += `//// ${q.text}\n`;
    q.incorrectAnswers.forEach((inc) => {
      output += `/// ${inc}\n`;
    });
    q.correctAnswers.forEach((cor) => {
      output += `// ${cor}\n`;
    });
    output += "\n";
  });
  return output;
}

/**
 * Returns true if local hour is after midnight and before 5:00 AM
 */
export function isBedtimeHour(): boolean {
  const currentHour = new Date().getHours();
  return currentHour >= 0 && currentHour < 5;
}
