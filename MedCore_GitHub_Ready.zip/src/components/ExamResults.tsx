import { useState } from "react";
import { CheckCircle2, AlertCircle, Bookmark, Download, Save, Home, ArrowRight, Share2, Award, Sparkles, BookOpen } from "lucide-react";
import { Question, SavedMistakeSet } from "../types";
import { exportMistakesToRawText } from "../utils";

interface ExamResultsProps {
  questions: Question[];
  userAnswers: { [questionId: string]: string };
  flaggedQuestionIds: { [questionId: string]: boolean };
  onRestartWithMistakes: () => void;
  onRestartWithFlags: () => void;
  onSaveMistakes: (name: string, questions: Question[]) => void;
  onResetToSetup: () => void;
}

export default function ExamResults({
  questions,
  userAnswers,
  flaggedQuestionIds,
  onRestartWithMistakes,
  onRestartWithFlags,
  onSaveMistakes,
  onResetToSetup,
}: ExamResultsProps) {
  const totalQuestions = questions.length;

  // Calculate stats
  let correctCount = 0;
  let incorrectCount = 0;
  const incorrectQuestionsList: Question[] = [];
  const flaggedQuestionsList: Question[] = [];

  questions.forEach((q) => {
    const ans = userAnswers[q.id];
    const isCorrect = ans === q.correctOptionText;
    if (ans) {
      if (isCorrect) {
        correctCount++;
      } else {
        incorrectCount++;
        incorrectQuestionsList.push(q);
      }
    } else {
      // Unanswered counts as mistake or skipped
      incorrectCount++;
      incorrectQuestionsList.push(q);
    }

    if (flaggedQuestionIds[q.id]) {
      flaggedQuestionsList.push(q);
    }
  });

  const correctPercent = totalQuestions > 0 ? Math.round((correctCount / totalQuestions) * 100) : 0;
  const errorPercent = totalQuestions > 0 ? (incorrectCount / totalQuestions) * 100 : 0;

  // Motivational Logic calculated EXACTLY based on error percent
  const isExcellent = errorPercent < 10; // Mistakes are LESS than 10%
  const motivationalMessage = isExcellent
    ? "შენი ჰიპოკამპი პიკზე მუშაობს! ბაზა უბრალოდ გაანადგურე. ამ შედეგით გამოცდაზე მხოლოდ ფორმალობისთვის თუ მიხვალ! 🧠🔥"
    : "მე ვარსებობ შენი წარმატებისთვის. ახლა მთავარია დოფამინის დონე აიმაღლო, ცოტა დაისვენო და კვლავ თავიდან ვცადოთ. ☕☘️";

  // Saved Mistakes properties
  const [saveName, setSaveName] = useState("");
  const [hasSaved, setHasSaved] = useState(false);

  const handleSaveMistakesInternally = () => {
    if (incorrectQuestionsList.length === 0) return;
    const dateStr = new Date().toLocaleDateString("ka-GE", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
    const defaultName = saveName.trim() || `შეცდომების_ბაზა_${dateStr}`;
    
    onSaveMistakes(defaultName, incorrectQuestionsList);
    setHasSaved(true);
  };

  const handleDownloadMistakesTxt = () => {
    if (incorrectQuestionsList.length === 0) return;
    const txtContent = exportMistakesToRawText(incorrectQuestionsList);
    const blob = new Blob([txtContent], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `სამედიცინო_შეცდომები_${new Date().toISOString().substring(0, 10)}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadMistakesJson = () => {
    if (incorrectQuestionsList.length === 0) return;
    const jsonContent = JSON.stringify(incorrectQuestionsList, null, 2);
    const blob = new Blob([jsonContent], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `სამედიცინო_შეცდომები_${new Date().toISOString().substring(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // SVG Circle stroke definitions
  const radius = 60;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (correctPercent / 100) * circumference;

  return (
    <div id="exam-results-screen" className="w-full max-w-3xl mx-auto space-y-8 animate-fade-in pb-12">
      
      {/* Upper Congrats and Motivational Card */}
      <div className={`p-6 sm:p-8 rounded-3xl border transition-all shadow-md relative overflow-hidden ${
        isExcellent 
          ? "border-emerald-200 bg-emerald-50/40 dark:border-emerald-900/30 dark:bg-emerald-950/15" 
          : "border-slate-200 bg-slate-50/40 dark:border-slate-800 dark:bg-slate-900/40"
      }`}>
        <div className="absolute right-0 top-0 translate-x-1/4 -translate-y-1/4 opacity-10 pointer-events-none">
          <Award className="w-64 h-64 text-emerald-500" />
        </div>

        <div className="flex flex-col md:flex-row items-center gap-6 relative z-10">
          {/* Circular SVG Donut Chart */}
          <div className="relative w-36 h-36 flex items-center justify-center shrink-0">
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="72"
                cy="72"
                r={radius}
                className="stroke-slate-100 dark:stroke-slate-800"
                strokeWidth="10"
                fill="transparent"
              />
              <circle
                cx="72"
                cy="72"
                r={radius}
                className={`transition-all duration-1000 ${
                  isExcellent ? "stroke-burgundy-600" : "stroke-amber-500"
                }`}
                strokeWidth="10"
                fill="transparent"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute flex flex-col items-center justify-center">
              <span className="text-3xl font-extrabold text-slate-900 dark:text-slate-100 tracking-tight">{correctPercent}%</span>
              <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mt-0.5">წარმატება</span>
            </div>
          </div>

          <div className="flex-1 text-center md:text-left space-y-3">
            <div className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-white dark:bg-slate-900 text-[10px] font-black uppercase text-burgundy-500 dark:text-burgundy-400 border border-slate-100 dark:border-slate-800 shadow-sm leading-none">
              <Sparkles className="w-3.5 h-3.5" />
              სხდომის ანალიტიკა
            </div>
            
            <h3 className="text-md sm:text-lg font-extrabold text-slate-800 dark:text-slate-100 font-sans tracking-tight leading-snug">
              {motivationalMessage}
            </h3>
          </div>
        </div>
      </div>

      {/* Structured Statistics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        
        <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl text-center shadow-sm">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">მთლიანი</span>
          <p className="text-2xl font-black text-slate-900 dark:text-slate-100 mt-1 font-mono">{totalQuestions}</p>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl text-center shadow-sm">
          <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-wider">სწორი</span>
          <p className="text-2xl font-black text-emerald-500 mt-1 font-mono">{correctCount}</p>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl text-center shadow-sm">
          <span className="text-[10px] font-bold text-rose-500 uppercase tracking-wider">შეცდომები</span>
          <p className="text-2xl font-black text-rose-500 mt-1 font-mono">{incorrectCount}</p>
        </div>

        <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-2xl text-center shadow-sm">
          <span className="text-[10px] font-bold text-amber-500 uppercase tracking-wider">მონიშნული</span>
          <p className="text-2xl font-black text-amber-500 mt-1 font-mono">{flaggedQuestionsList.length}</p>
        </div>

      </div>

      {/* Actions and Revision Loop Panels */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

        {/* revision controllers */}
        <div className="p-6 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl space-y-4 flex flex-col justify-between">
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 font-sans flex items-center gap-1.5">
              <BookOpen className="w-4 h-4 text-burgundy-500" />
              შეცდომებისა და მონიშნულების გამეორება
            </h4>
            <p className="text-xs text-slate-400 font-sans leading-relaxed">
              გაუშვი მიზანმიმართული სესიები მხოლოდ დაშვებული შეცდომების გასასწორებლად ან მონიშნული კლოზეტების გადასაკითხად.
            </p>
          </div>

          <div className="space-y-2.5 pt-4">
            <button
              id="restart-mistakes-only-btn"
              disabled={incorrectCount === 0}
              onClick={onRestartWithMistakes}
              className="w-full py-3 px-4 bg-rose-500 hover:bg-rose-600 disabled:opacity-40 text-white text-xs font-bold rounded-xl flex items-center justify-between transition-all cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                🧠 მხოლოდ შეცდომების გავლა
              </span>
              <span className="font-mono bg-white/25 px-2 py-0.5 rounded-full text-[10px]">{incorrectCount} კითხვა</span>
            </button>

            <button
              id="restart-flags-only-btn"
              disabled={flaggedQuestionsList.length === 0}
              onClick={onRestartWithFlags}
              className="w-full py-3 px-4 bg-amber-500 hover:bg-amber-600 disabled:opacity-40 text-white text-xs font-bold rounded-xl flex items-center justify-between transition-all cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <Bookmark className="w-4 h-4" />
                ⭐ მონიშნული კითხვების გადაკითხვა
              </span>
              <span className="font-mono bg-white/25 px-2 py-0.5 rounded-full text-[10px]">{flaggedQuestionsList.length} კითხვა</span>
            </button>
          </div>
        </div>

        {/* download export controllers */}
        <div className="p-6 bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl space-y-4 flex flex-col justify-between">
          <div className="space-y-2">
            <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 font-sans flex items-center gap-1.5">
              <Save className="w-4 h-4 text-burgundy-500" />
              ბაზის შენახვა & ჩამოტვირთვის ცენტრი
            </h4>
            <p className="text-xs text-slate-400 font-sans leading-relaxed">
              შეგიძლია შეინახო შეცდომები ლოკალურად ან გადმოწერო ისინი .txt საგამოცდო ფორმატში სხვა დღეს სამუშაოდ.
            </p>
          </div>

          {incorrectCount > 0 ? (
            <div className="space-y-3 pt-3">
              {/* Internal Saving Input */}
              <div className="flex gap-2">
                <input
                  id="mistakes-saving-name-input"
                  type="text"
                  placeholder="ბაზის სახელი..."
                  value={saveName}
                  onChange={e => setSaveName(e.target.value)}
                  disabled={hasSaved}
                  className="flex-1 px-3 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:border-burgundy-500 rounded-xl"
                />
                <button
                  id="save-mistakes-internally-btn"
                  onClick={handleSaveMistakesInternally}
                  disabled={hasSaved}
                  className="px-3.5 py-1.5 bg-burgundy-600 hover:bg-burgundy-550 text-white text-xs font-bold rounded-xl transition-all disabled:bg-slate-850 dark:disabled:bg-slate-800 dark:disabled:text-slate-500 cursor-pointer flex items-center gap-1 shrink-0"
                >
                  <Save className="w-3.5 h-3.5" />
                  {hasSaved ? "შენახულია" : "შენახვა"}
                </button>
              </div>

              {/* Downloads Row */}
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  id="download-as-txt-btn"
                  onClick={handleDownloadMistakesTxt}
                  className="py-2 px-3 border border-slate-200 dark:border-slate-800 rounded-xl hover:border-burgundy-500 text-slate-700 dark:text-slate-300 transition-all text-[11px] font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  ჩამოტვირთვა (.TXT)
                </button>
                <button
                  id="download-as-json-btn"
                  onClick={handleDownloadMistakesJson}
                  className="py-2 px-3 border border-slate-200 dark:border-slate-800 rounded-xl hover:border-burgundy-500 text-slate-700 dark:text-slate-300 transition-all text-[11px] font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  ჩამოტვირთვა (.JSON)
                </button>
              </div>
            </div>
          ) : (
            <div className="p-3 text-center text-emerald-500 bg-emerald-50/20 dark:bg-emerald-950/10 border border-emerald-500/10 rounded-xl text-[11px] font-bold leading-none mt-4">
              ✨ გილოცავთ! თქვენ არ გაქვთ შეცდომები შესანახად.
            </div>
          )}

        </div>

      </div>

      {/* Return home anchor */}
      <div className="flex justify-center pt-2">
        <button
          id="return-home-from-results"
          onClick={onResetToSetup}
          className="px-8 py-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl font-bold text-xs flex items-center gap-2 hover:opacity-90 transition-all cursor-pointer shadow-md"
        >
          <Home className="w-4 h-4" />
          დაფაზე დაბრუნება (მთავარი)
        </button>
      </div>

    </div>
  );
}
