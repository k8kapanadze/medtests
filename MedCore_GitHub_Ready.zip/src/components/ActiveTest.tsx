import { useState, useEffect } from "react";
import { Star, ArrowRight, Pause, RotateCcw, Volume2, Sparkles, AlertCircle, Play } from "lucide-react";
import { Question, QuizSession } from "../types";

interface ActiveTestProps {
  session: QuizSession;
  onAnswerQuestion: (questionId: string, answerText: string) => void;
  onToggleFlag: (questionId: string) => void;
  onGoToNextQuestion: () => void;
  onGoToQuestionIndex: (index: number) => void;
  onPauseQuiz: () => void;
  onStartMistakesSubMode: () => void;
  onFinishQuiz: () => void;
}

export default function ActiveTest({
  session,
  onAnswerQuestion,
  onToggleFlag,
  onGoToNextQuestion,
  onGoToQuestionIndex,
  onPauseQuiz,
  onStartMistakesSubMode,
  onFinishQuiz,
}: ActiveTestProps) {
  const {
    questions,
    currentQuestionIndex,
    userAnswers,
    flaggedQuestionIds,
    mistakes,
    isAutoMode,
    isReviewingMistakes,
  } = session;

  const currentQuestion: Question | undefined = questions[currentQuestionIndex];
  const selectedAnswer = currentQuestion ? userAnswers[currentQuestion.id] : undefined;

  // Track if we made a wrong choice on the current question to force manual "Next"
  const [hasRevealedIncorrect, setHasRevealedIncorrect] = useState(false);
  const [jumpInput, setJumpInput] = useState("");

  // Reset incorrect trigger upon index progression
  useEffect(() => {
    setHasRevealedIncorrect(false);
  }, [currentQuestionIndex, questions]);

  // Hook keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore keys if input is focused
      if (document.activeElement?.tagName === "INPUT" || document.activeElement?.tagName === "TEXTAREA") {
        return;
      }

      const key = e.key.toLowerCase();

      if (!currentQuestion) return;

      // Map options
      if (!selectedAnswer) {
        const optionIndexMap = ["1", "2", "3", "4", "5", "6"];
        const optionCharMap = ["a", "b", "c", "d", "e", "f"];

        let chosenIndex = -1;
        if (optionIndexMap.includes(key)) {
          chosenIndex = optionIndexMap.indexOf(key);
        } else if (optionCharMap.includes(key)) {
          chosenIndex = optionCharMap.indexOf(key);
        }

        if (chosenIndex >= 0 && chosenIndex < currentQuestion.options.length) {
          const answerText = currentQuestion.options[chosenIndex];
          handleAnswerSelect(answerText);
        }
      } else {
        // Advancing question via Enter or Space
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          handleNextAdvance();
        }
      }

      // Flagging toggle via 'f' or 's' keys
      if (key === "f" || key === "s") {
        if (currentQuestion) {
          onToggleFlag(currentQuestion.id);
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentQuestion, selectedAnswer, session]);

  if (!currentQuestion) {
    return (
      <div className="text-center py-12 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 max-w-lg mx-auto">
        <AlertCircle className="w-12 h-12 text-rose-500 mx-auto mb-4" />
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100 font-sans">
          ტესტირების შეცდომა
        </h3>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
          დაუმუშავებელი ინფორმაციის ნაკადი. გთხოვთ, თავიდან ჩატვირთოთ ფაილი.
        </p>
        <button
          onClick={onPauseQuiz}
          className="mt-6 px-6 py-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-medium text-xs rounded-xl hover:opacity-90 transition-all cursor-pointer"
        >
          უკან დაბრუნება
        </button>
      </div>
    );
  }

  const isCorrect = selectedAnswer === currentQuestion.correctOptionText;
  const isAnswered = selectedAnswer !== undefined;

  const handleAnswerSelect = (optionText: string) => {
    if (isAnswered) return; // Allow answering only once

    onAnswerQuestion(currentQuestion.id, optionText);

    const correct = optionText === currentQuestion.correctOptionText;

    if (!correct) {
      setHasRevealedIncorrect(true);
    } else if (isAutoMode) {
      // Auto Mode correct answer: trigger instant transition
      setTimeout(() => {
        handleNextAdvance();
      }, 350);
    }
  };

  const handleNextAdvance = () => {
    if (currentQuestionIndex + 1 >= questions.length) {
      onFinishQuiz();
    } else {
      onGoToNextQuestion();
    }
  };

  const totalQuestions = questions.length;
  const progressPercent = Math.min(((currentQuestionIndex + 1) / totalQuestions) * 100, 100);

  return (
    <div id="active-quiz-component" className="w-full max-w-3xl mx-auto space-y-6 animate-fade-in">
      
      {/* Top Session Progress Bar and Settings Indicators */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
        
        {/* Upper stats row */}
        <div className="flex justify-between items-center text-xs flex-wrap gap-3">
          <div className="flex items-center gap-3 flex-wrap">
            <span className="font-mono bg-burgundy-500/10 text-burgundy-400 px-3 py-1.5 rounded-xl font-bold">
              კითხვა {currentQuestionIndex + 1} / {totalQuestions}
            </span>
            
            {/* Backward / Forward and Direct Jump Deck */}
            <div className="flex items-center gap-1.5 bg-slate-100/60 dark:bg-slate-950 p-1 rounded-xl border border-slate-200/40 dark:border-slate-800">
              <button
                disabled={currentQuestionIndex === 0}
                onClick={() => onGoToQuestionIndex(currentQuestionIndex - 1)}
                className="px-1.5 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-550 dark:text-slate-455 font-sans font-bold text-xs transition-colors cursor-pointer"
                title="წინა კითხვა"
              >
                წინა
              </button>
              
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min="1"
                  max={totalQuestions}
                  value={jumpInput}
                  onChange={e => setJumpInput(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === "Enter") {
                      const idx = parseInt(jumpInput, 10);
                      if (!isNaN(idx) && idx >= 1 && idx <= totalQuestions) {
                        onGoToQuestionIndex(idx - 1);
                        setJumpInput("");
                      }
                    }
                  }}
                  placeholder={`${currentQuestionIndex + 1}`}
                  className="w-11 px-1 py-0.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-[11px] font-mono text-center font-bold text-slate-850 dark:text-slate-150 rounded-md focus:outline-none focus:border-burgundy-500"
                />
                <button
                  onClick={() => {
                    const idx = parseInt(jumpInput, 10);
                    if (!isNaN(idx) && idx >= 1 && idx <= totalQuestions) {
                      onGoToQuestionIndex(idx - 1);
                      setJumpInput("");
                    }
                  }}
                  className="text-[10px] bg-burgundy-600 hover:bg-burgundy-500 text-white px-2.5 py-1 rounded-md font-sans font-extrabold transition-all cursor-pointer"
                >
                  გადასვლა
                </button>
              </div>

              <button
                disabled={currentQuestionIndex >= totalQuestions - 1}
                onClick={() => onGoToQuestionIndex(currentQuestionIndex + 1)}
                className="px-1.5 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-550 dark:text-slate-455 font-sans font-bold text-xs transition-colors cursor-pointer"
                title="შემდეგი კითხვა"
              >
                შემდეგი
              </button>
            </div>

            {isReviewingMistakes && (
              <span className="font-sans bg-rose-500/10 text-rose-600 dark:text-rose-400 px-3 py-1.5 rounded-xl font-bold animate-pulse">
                შეცდომების კორექცია
              </span>
            )}
          </div>

          <div className="flex gap-2">
            {/* Go through mistakes now button - (Hidden mistake count keeps focus) */}
            {mistakes.length > 0 && !isReviewingMistakes && (
              <button
                id="solve-mistakes-now-btn"
                onClick={onStartMistakesSubMode}
                className="px-3.5 py-1.5 rounded-xl bg-orange-500/10 text-orange-600 dark:text-orange-400 font-bold hover:bg-orange-500 hover:text-white transition-all text-[11px] cursor-pointer animation-pulse"
                title="ნებისმიერ დროს შეგიძლიათ შეაჩეროთ ძირითადი ტესტი და გააკეთოთ დაშვებული შეცდომები"
              >
                შეცდომების გავლა ახლავე ({mistakes.length})
              </button>
            )}

            <button
              id="pause-quiz-session"
              onClick={onPauseQuiz}
              className="px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 hover:bg-slate-100 hover:text-slate-800 transition-colors text-[11px] font-sans font-bold flex items-center gap-1 cursor-pointer"
            >
              <Pause className="w-3.5 h-3.5" />
              დახურვა
            </button>
          </div>
        </div>

        {/* Real-time fluid progress indicator */}
        <div className="relative w-full h-2 bg-slate-100 dark:bg-slate-950 rounded-full overflow-hidden border border-slate-300 dark:border-slate-800">
          <div 
            className="absolute top-0 bottom-0 left-0 bg-burgundy-600 rounded-full transition-all duration-300 shadow-[0_0_8px_rgba(145,14,43,0.30)] animate-pulse"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Source file info bar */}
        <div className="flex justify-between items-center text-[10px] text-slate-400">
          <span>წყარო: <strong className="text-slate-600 dark:text-slate-300 font-sans">{currentQuestion.sourceFile}</strong></span>
          <span className="font-mono">პროგრესი: {Math.round(progressPercent)}%</span>
        </div>
      </div>

      {/* Main Single Question Box */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-md space-y-6">
        
        {/* Question Header & Bookmark Toggle */}
        <div className="flex gap-4 items-start justify-between">
          <div className="space-y-1">
            <span className="text-[10px] font-bold tracking-wider text-slate-400 uppercase font-mono">
              სამედიცინო შემთხვევა / კითხვა
            </span>
            <h3 className="text-md sm:text-lg font-bold text-slate-900 dark:text-slate-100 font-sans leading-relaxed tracking-tight">
              {currentQuestion.text}
            </h3>
          </div>

          <button
            id={`flag-question-${currentQuestion.id}`}
            onClick={() => onToggleFlag(currentQuestion.id)}
            className={`p-2.5 rounded-xl border transition-all cursor-pointer ${
              flaggedQuestionIds[currentQuestion.id]
                ? "border-amber-500 bg-amber-500/10 text-amber-500"
                : "border-slate-200 dark:border-slate-800 hover:border-amber-400 text-slate-400 hover:text-amber-500"
            }`}
            title="მონიშვნა შემდგომი გადაკითხვისთვის (Flag/Unflag)"
          >
            <Star className={`w-5 h-5 ${flaggedQuestionIds[currentQuestion.id] ? "fill-amber-500" : ""}`} />
          </button>
        </div>

        {/* Options grid */}
        <div className="grid grid-cols-1 gap-3.5 pt-2">
          {currentQuestion.options.map((option, idx) => {
            const isOptionSelected = selectedAnswer === option;
            const isOptionCorrect = option === currentQuestion.correctOptionText;

            let optionStyle = "border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/20 text-slate-800 dark:text-slate-200 hover:border-slate-200 dark:hover:border-slate-700 hover:bg-slate-100/40 dark:hover:bg-slate-950/40";
            
            if (isAnswered) {
              if (isOptionCorrect) {
                // Correct answer always flashes green once answered
                optionStyle = "border-emerald-500 dark:border-emerald-500 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-bold scale-[1.002] ring-1 ring-emerald-500/25";
              } else if (isOptionSelected) {
                // If this is selected but incorrect, color it deep red
                optionStyle = "border-rose-500 dark:border-rose-500 bg-rose-500/10 text-rose-600 dark:text-rose-400 font-bold";
              } else {
                // Non-selected incorrect choices fade slightly
                optionStyle = "border-slate-200 dark:border-slate-800 bg-slate-50/30 dark:bg-slate-950/10 text-slate-400 dark:text-slate-600 opacity-60";
              }
            }

            const shortcutLetter = ["A", "B", "C", "D", "E", "F"][idx] || "";

            return (
              <button
                id={`option-${idx}`}
                key={idx}
                disabled={isAnswered}
                onClick={() => handleAnswerSelect(option)}
                className={`w-full p-4 rounded-2xl text-left border text-xs sm:text-sm font-sans flex items-center justify-between gap-4 transition-all duration-200 cursor-pointer ${optionStyle} min-h-[56px]`}
              >
                <div className="flex items-center gap-3.5 pr-2">
                  {/* Keyboard bubble label for easy accessibility */}
                  <span className={`w-6 h-6 rounded-lg text-[10px] font-extrabold flex items-center justify-center shrink-0 border ${
                    isOptionSelected 
                      ? "bg-white dark:bg-slate-900 border-current" 
                      : "bg-white dark:bg-slate-900/60 border-slate-200 dark:border-slate-800 text-slate-400"
                  }`}>
                    {shortcutLetter}
                  </span>
                  <span>{option}</span>
                </div>
                
                {/* Visual state bullets */}
                {isAnswered && (
                  <div className="shrink-0 font-extrabold text-[10px] uppercase font-sans tracking-wider">
                    {isOptionCorrect && <span className="text-emerald-500">სწორია</span>}
                    {isOptionSelected && !isOptionCorrect && <span className="text-rose-500">მცდარია</span>}
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Lower interactive buttons (Next button & tips) */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800 flex-wrap gap-4">
          
          <div className="text-[10px] text-slate-400 font-sans flex items-center gap-1">
            <span className="font-mono bg-slate-100 dark:bg-slate-950 px-1.5 py-0.5 rounded text-slate-500 dark:text-slate-400">1-4</span> 
            ვარიანტები &bull; 
            <span className="font-mono bg-slate-100 dark:bg-slate-950 px-1.5 py-0.5 rounded text-slate-500 dark:text-slate-400">F</span> 
            მონიშვნა &bull; 
            <span className="font-mono bg-slate-100 dark:bg-slate-950 px-1.5 py-0.5 rounded text-slate-500 dark:text-slate-400">Space</span> 
            შემდეგი კითხვა
          </div>

          {/* Reveal Next manually if automatic mode is off or user selected wrong answer */}
          {isAnswered && (!isAutoMode || hasRevealedIncorrect) && (
            <button
              id="advance-question-btn"
              onClick={handleNextAdvance}
              className="px-6 py-2.5 bg-burgundy-600 hover:bg-burgundy-500 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all shadow-md active:scale-95 cursor-pointer ml-auto uppercase tracking-wider"
            >
              {currentQuestionIndex + 1 === questions.length ? "შედეგების ნახვა" : "შემდეგი კითხვა"}
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
