import { useState, useEffect } from "react";
import { Moon, X } from "lucide-react";
import { isBedtimeHour } from "../utils";

export default function ClockWarning() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    // Initial check
    setShow(isBedtimeHour());

    // Check every minute
    const interval = setInterval(() => {
      setShow(isBedtimeHour());
    }, 60000);

    return () => clearInterval(interval);
  }, []);

  if (!show) return null;

  return (
    <div
      id="clock-warning-banner"
      className="mb-8 p-4 rounded-2xl border border-amber-200 bg-amber-50/90 dark:border-amber-900/40 dark:bg-amber-950/25 text-amber-900 dark:text-amber-200 shadow-sm flex items-center justify-between gap-4 animate-fade-in"
    >
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-xl bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400">
          <Moon className="w-5 h-5" />
        </div>
        <div>
          <h4 className="text-sm font-semibold tracking-tight font-sans">
            შეხედე საათს! ძილის დროა. 🌙
          </h4>
          <p className="text-xs text-amber-800/80 dark:text-amber-300/80 mt-0.5">
            სამედიცინო ინფორმაციის კონსოლიდაცია და გრძელვადიან მეხსიერებაში გადატანა ხდება ძილის ღრმა ფაზებში. გაუფრთხილდი თავს!
          </p>
        </div>
      </div>
      <button
        id="close-clock-warning-btn"
        onClick={() => setShow(false)}
        className="p-1.5 rounded-lg hover:bg-amber-100 dark:hover:bg-amber-900/40 transition-colors"
      >
        <X className="w-4 h-4" />
      </button>
    </div>
  );
}
