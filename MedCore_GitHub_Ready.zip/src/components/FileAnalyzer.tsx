import React, { useState, useRef } from "react";
import { Upload, FileText, Trash2, Settings, Play, Filter, AlertCircle, Sparkles, Check, Brain } from "lucide-react";
import { Question, UploadedFile, SavedMistakeSet } from "../types";
import { parseQuestionsText, prepareQuestions } from "../utils";

interface FileAnalyzerProps {
  uploadedFiles: UploadedFile[];
  onAddFiles: (files: UploadedFile[]) => void;
  onDeleteFile: (id: string) => void;
  onStartQuiz: (
    questions: Question[],
    isAutoMode: boolean,
    isQuestsShuffled: boolean,
    isOptsShuffled: boolean,
    initIndex?: number
  ) => void;
  savedMistakes: SavedMistakeSet[];
  onLoadSavedMistakes: (set: SavedMistakeSet) => void;
  onDeleteSavedMistakes: (id: string) => void;
  preloadedDefaultFiles: () => void;
}

export default function FileAnalyzer({
  uploadedFiles,
  onAddFiles,
  onDeleteFile,
  onStartQuiz,
  savedMistakes,
  onLoadSavedMistakes,
  onDeleteSavedMistakes,
  preloadedDefaultFiles,
}: FileAnalyzerProps) {
  const [activeTab, setActiveTab] = useState<"single" | "multi" | "saved">("single");
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Single File Test Settings
  const [selectedFileId, setSelectedFileId] = useState<string>("");
  const [rangeStart, setRangeStart] = useState<string>("");
  const [rangeEnd, setRangeEnd] = useState<string>("");
  const [cutStart, setCutStart] = useState<string>("");
  const [cutEnd, setCutEnd] = useState<string>("");
  const [startIndex, setStartIndex] = useState<string>("");
  const [shuffleQuests, setShuffleQuests] = useState(true);
  const [shuffleOpts, setShuffleOpts] = useState(true);
  const [isAutoMode, setIsAutoMode] = useState(true);

  // Multi File Simulator Settings
  const [multiQuotas, setMultiQuotas] = useState<{ [fileId: string]: string }>({});
  const [multiFileErrors, setMultiFileErrors] = useState<string>("");

  // Sync / select active file when uploads update
  React.useEffect(() => {
    if (uploadedFiles.length > 0 && (!selectedFileId || !uploadedFiles.some(f => f.id === selectedFileId))) {
      setSelectedFileId(uploadedFiles[0].id);
    }
  }, [uploadedFiles, selectedFileId]);

  const currentFile = uploadedFiles.find(f => f.id === selectedFileId);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFilesUpload(e.dataTransfer.files);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFilesUpload(e.target.files);
    }
  };

  const handleFilesUpload = async (fileList: FileList) => {
    const parsedFiles: UploadedFile[] = [];

    for (let i = 0; i < fileList.length; i++) {
      const file = fileList[i];
      const text = await file.text();
      const questions = parseQuestionsText(text, file.name);

      if (questions.length > 0) {
        parsedFiles.push({
          id: Math.random().toString(36).substring(2, 11) + "-" + Date.now(),
          name: file.name,
          totalQuestions: questions.length,
          questions,
          timestamp: new Date().toLocaleTimeString("ka-GE", { hour: "2-digit", minute: "2-digit" }),
        });
      }
    }

    if (parsedFiles.length > 0) {
      onAddFiles(parsedFiles);
      setSelectedFileId(parsedFiles[0].id);
    }
  };

  const handleLaunchSingleQuiz = () => {
    if (!currentFile) return;

    let targetQuestions = [...currentFile.questions];

    // Filter specific range
    const s = parseInt(rangeStart, 10);
    const e = parseInt(rangeEnd, 10);
    if (!isNaN(s) && s > 0) {
      const actualEnd = !isNaN(e) && e <= targetQuestions.length ? e : targetQuestions.length;
      targetQuestions = targetQuestions.slice(s - 1, actualEnd);
    }

    // Cut range (Exclude questions)
    const cs = parseInt(cutStart, 10);
    const ce = parseInt(cutEnd, 10);
    if (!isNaN(cs) && cs > 0 && !isNaN(ce) && ce >= cs) {
      const originalStartIndex = s > 0 ? s : 1;
      const targetToRemoveStart = cs - originalStartIndex;
      const targetToRemoveEnd = ce - originalStartIndex;
      
      if (targetToRemoveStart >= 0 && targetToRemoveStart < targetQuestions.length) {
        targetQuestions.splice(targetToRemoveStart, Math.min(targetToRemoveEnd - targetToRemoveStart + 1, targetQuestions.length - targetToRemoveStart));
      }
    }

    // Start index offset
    const idx = parseInt(startIndex, 10);
    let initialIndexToStart = 0;
    if (!isNaN(idx) && idx > 0) {
      const originalStartIndex = s > 0 ? s : 1;
      const selectOffset = idx - originalStartIndex;
      if (selectOffset >= 0 && selectOffset < targetQuestions.length) {
        initialIndexToStart = selectOffset;
      }
    }

    const prepared = prepareQuestions(targetQuestions, shuffleQuests, shuffleOpts);
    onStartQuiz(prepared, isAutoMode, shuffleQuests, shuffleOpts, initialIndexToStart);
  };

  const handleLaunchMultiQuiz = () => {
    setMultiFileErrors("");
    let mergedQuestions: Question[] = [];
    let hasError = false;

    uploadedFiles.forEach(file => {
      const requestedAmt = parseInt(multiQuotas[file.id] || "0", 10);
      if (requestedAmt <= 0) return;

      if (requestedAmt > file.questions.length) {
        setMultiFileErrors(`ფაილში "${file.name}" არ არის საკმარისი კითხვები. მოთხოვნილია: ${requestedAmt}, ხელმისაწვდომია: ${file.questions.length}`);
        hasError = true;
        return;
      }

      const fileQuestions = prepareQuestions(file.questions, true, false).slice(0, requestedAmt);
      mergedQuestions = [...mergedQuestions, ...fileQuestions];
    });

    if (hasError) return;

    if (mergedQuestions.length === 0) {
      setMultiFileErrors("გთხოვთ მიუთითოთ კითხვების რაოდენობა მინიმუმ ერთი ფაილისთვის სიმულაციის დასაწყებად.");
      return;
    }

    const finalPreparedQuestions = prepareQuestions(mergedQuestions, true, shuffleOpts);
    onStartQuiz(finalPreparedQuestions, isAutoMode, true, shuffleOpts);
  };

  const handleSetMultiQuota = (fileId: string, value: string) => {
    setMultiQuotas(prev => ({
      ...prev,
      [fileId]: value
    }));
  };

  const loadPresetQuotas = (proportion: number) => {
    const updated: Record<string, string> = {};
    uploadedFiles.forEach(f => {
      const amt = Math.floor(f.questions.length * proportion);
      updated[f.id] = amt > 0 ? amt.toString() : "1";
    });
    setMultiQuotas(updated);
  };

  const totalQuestions = uploadedFiles.reduce((acc, f) => acc + f.questions.length, 0);

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 animate-fade-in">
      
      {/* 📥 minimalist standard upload box always present on the main interface */}
      <div 
        id="file-drop-container"
        onDragEnter={handleDrag}
        onDragOver={handleDrag}
        onDragLeave={handleDrag}
        onDrop={handleDrop}
        className={`relative border-2 border-dashed rounded-2xl p-6 text-center transition-all ${
          dragActive 
            ? "border-burgundy-500 bg-burgundy-500/5 scale-[0.99]" 
            : "border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 hover:border-slate-350 dark:hover:border-slate-700 shadow-sm"
        }`}
      >
        <input 
          ref={fileInputRef}
          type="file" 
          multiple
          accept=".txt"
          onChange={handleFileInput}
          className="hidden" 
        />
        
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3.5 text-left">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 text-slate-400 group-hover:scale-105 transition-transform border border-slate-100 dark:border-slate-800">
              <Upload className="w-5 h-5 text-burgundy-500" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-850 dark:text-slate-100 font-sans">
                ატვირთე საგამოცდო .TXT ბაზები
              </h4>
              <p className="text-[11px] text-slate-450 dark:text-slate-400 mt-0.5">
                გამოიყენე Drag & Drop ან აირჩიე ფაილი. {uploadedFiles.length > 0 && <span className="text-emerald-500 font-semibold">(ჩატვირთულია {uploadedFiles.length} ბაზა, ჯამში {totalQuestions} კითხვა)</span>}
              </p>
            </div>
          </div>

          <div className="flex gap-2 w-full sm:w-auto">
            <button
              id="select-file-button"
              onClick={() => fileInputRef.current?.click()}
              className="flex-1 sm:flex-initial px-4 py-2 rounded-xl bg-burgundy-500 hover:bg-burgundy-600 dark:bg-burgundy-600 dark:hover:bg-burgundy-500 text-white font-bold text-xs shadow-sm transition-all cursor-pointer whitespace-nowrap"
            >
              ფაილის არჩევა
            </button>
            <button
              id="quick-load-default"
              onClick={preloadedDefaultFiles}
              className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-950 hover:bg-slate-100 dark:hover:bg-slate-900 font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
              title="სადემონსტრაციო მიმართულებების აღდგენა"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              დემო ბაზები
            </button>
          </div>
        </div>
      </div>

      {/* 🏛️ 3 Tab Navigation for the 3 user requested screens */}
      <div className="flex bg-slate-100/55 dark:bg-slate-950/60 p-1 rounded-2xl border border-slate-200/80 dark:border-slate-800/80 gap-1 overflow-x-auto shadow-sm">
        <button
          id="tab-single"
          onClick={() => setActiveTab("single")}
          className={`py-3 px-4 font-bold rounded-xl transition-all text-xs uppercase tracking-wider cursor-pointer whitespace-nowrap flex items-center gap-2 flex-1 justify-center ${
            activeTab === "single" 
              ? "bg-white dark:bg-slate-900 text-burgundy-500 dark:text-burgundy-405 shadow-sm border border-slate-200 dark:border-slate-800" 
              : "text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
          }`}
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          ლოკალური ტესტი
        </button>
        
        <button
          id="tab-multi"
          onClick={() => setActiveTab("multi")}
          className={`py-3 px-4 font-bold rounded-xl transition-all text-xs uppercase tracking-wider cursor-pointer whitespace-nowrap flex items-center gap-2 flex-1 justify-center ${
            activeTab === "multi" 
              ? "bg-white dark:bg-slate-900 text-burgundy-500 dark:text-burgundy-405 shadow-sm border border-slate-200 dark:border-slate-800" 
              : "text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
          }`}
        >
          <Filter className="w-3.5 h-3.5" />
          გამოცდის სიმულატორი
        </button>
        
        <button
          id="tab-saved"
          onClick={() => setActiveTab("saved")}
          className={`py-3 px-4 font-bold rounded-xl transition-all text-xs uppercase tracking-wider cursor-pointer whitespace-nowrap flex items-center gap-2 flex-1 justify-center ${
            activeTab === "saved" 
              ? "bg-white dark:bg-slate-900 text-burgundy-500 dark:text-burgundy-405 shadow-sm border border-slate-200 dark:border-slate-800" 
              : "text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
          }`}
        >
          <Check className="w-3.5 h-3.5" />
          შენახული შეცდომები ({savedMistakes.length})
        </button>
      </div>

      {/* ⚙️ Screen Contents */}
      
      {/* 🎬 1. LOCAL SINGLE TEST VIEW */}
      {activeTab === "single" && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200/70 dark:border-slate-800/85 rounded-2xl p-6 space-y-6 shadow-sm">
          {uploadedFiles.length === 0 ? (
            <div className="p-12 text-center text-slate-400 dark:text-slate-500 border border-dashed border-slate-100 dark:border-slate-800 rounded-xl space-y-3">
              <Brain className="w-8 h-8 mx-auto text-slate-300 dark:text-slate-705" />
              <p className="text-xs font-sans font-medium">სისტემაში ბაზა ჯერ არ არის ჩატვირთული. გთხოვთ აირჩიოთ ან ჩააგდოთ ტექსტური ფაილი ზედა ველში.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
              
              {/* Select & Custom Slicing Parameters Card */}
              <div className="space-y-4">
                <div>
                  <label className="block text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2 font-sans">
                    აირჩიე აქტიური ბლოკი
                  </label>
                  <select
                    id="active-file-selector"
                    value={selectedFileId}
                    onChange={e => setSelectedFileId(e.target.value)}
                    className="w-full px-3 py-2.5 bg-slate-55 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl text-xs font-sans font-bold text-slate-800 dark:text-slate-200 focus:outline-none transition-all cursor-pointer"
                  >
                    {uploadedFiles.map(f => (
                      <option key={f.id} value={f.id}>
                        {f.name} ({f.totalQuestions} კითხვა)
                      </option>
                    ))}
                  </select>
                </div>

                {/* Slicing Controls */}
                <div className="space-y-3 pt-2">
                  <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
                    <Filter className="w-3.5 h-3.5 text-burgundy-500" />
                    <span className="text-[10px] font-black uppercase tracking-wider font-sans">კონფიგურაცია და ამოჭრა</span>
                  </div>

                  <div className="space-y-3">
                    {/* Range Select */}
                    <div className="space-y-1">
                      <label className="block text-[9.5px] font-bold text-slate-450 dark:text-slate-400">
                        სავარჯიშო დიაპაზონი (დიაპაზონის დატოვება)
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        <input
                          id="range-start-input"
                          type="number"
                          placeholder="დან (მაგ. 1)"
                          value={rangeStart}
                          onChange={e => setRangeStart(e.target.value)}
                          className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-800 dark:text-slate-200 focus:outline-none"
                        />
                        <input
                          id="range-end-input"
                          type="number"
                          placeholder={`მდე (მაგ. ${currentFile?.totalQuestions || 100})`}
                          value={rangeEnd}
                          onChange={e => setRangeEnd(e.target.value)}
                          className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-800 dark:text-slate-200 focus:outline-none"
                        />
                      </div>
                    </div>

                    {/* Exclude Range */}
                    <div className="space-y-1">
                      <label className="block text-[9.5px] font-bold text-slate-450 dark:text-slate-400">
                        მონაკვეთის სრულად ამოღება
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        <input
                          id="cut-start-input"
                          type="number"
                          placeholder="ამ ნომრიდან"
                          value={cutStart}
                          onChange={e => setCutStart(e.target.value)}
                          className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-800 dark:text-slate-200 focus:outline-none"
                        />
                        <input
                          id="cut-end-input"
                          type="number"
                          placeholder="ამ ნომრამდე"
                          value={cutEnd}
                          onChange={e => setCutEnd(e.target.value)}
                          className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-800 dark:text-slate-200 focus:outline-none"
                        />
                      </div>
                    </div>

                    {/* Start Offset */}
                    <div className="space-y-1">
                      <label className="block text-[9.5px] font-bold text-slate-450 dark:text-slate-400">
                        დაწყების პოზიცია (რომელი კითხვიდან დაიწყოს)
                      </label>
                      <input
                        id="start-index-input"
                        type="number"
                        placeholder="მაგ. დაიწყე პირდაპირ 80-ე კითხვით"
                        value={startIndex}
                        onChange={e => setStartIndex(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:border-burgundy-550"
                      />
                    </div>
                  </div>
                </div>

              </div>

              {/* Toggles and Simulator Initiation Card */}
              <div className="flex flex-col justify-between h-full space-y-5 pt-2">
                <div className="space-y-4">
                  <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
                    <Settings className="w-3.5 h-3.5 text-burgundy-550" />
                    <span className="text-[10px] font-black uppercase tracking-wider font-sans">ალგორითმი და პარამეტრები</span>
                  </div>

                  <div className="space-y-3 bg-slate-50 dark:bg-slate-950 p-4 rounded-xl border border-slate-100 dark:border-slate-850">
                    <label className="flex items-center justify-between cursor-pointer">
                      <div>
                        <span className="text-xs font-bold text-slate-700 dark:text-slate-300">კითხვების არევა</span>
                        <p className="text-[9.5px] text-slate-400">სლაიდების შემთხვევითი თანმიმდევრობა</p>
                      </div>
                      <input
                        id="shuffle-quests-toggle"
                        type="checkbox"
                        checked={shuffleQuests}
                        onChange={() => setShuffleQuests(!shuffleQuests)}
                        className="w-4 h-4 accent-burgundy-500 cursor-pointer"
                      />
                    </label>

                    <label className="flex items-center justify-between border-t border-slate-100/50 dark:border-slate-900 pt-2.5 cursor-pointer">
                      <div>
                        <span className="text-xs font-bold text-slate-700 dark:text-slate-300">პასუხების არევა</span>
                        <p className="text-[9.5px] text-slate-400">სწორი/არასწორი არჩევანის პოზიციების გადანაცვლება</p>
                      </div>
                      <input
                        id="shuffle-opts-toggle"
                        type="checkbox"
                        checked={shuffleOpts}
                        onChange={() => setShuffleOpts(!shuffleOpts)}
                        className="w-4 h-4 accent-burgundy-500 cursor-pointer"
                      />
                    </label>

                    <div className="border-t border-slate-100/50 dark:border-slate-900 pt-3">
                      <span className="text-[9px] font-black text-slate-400 uppercase block mb-2">გადასვლის ალგორითმი</span>
                      <div className="grid grid-cols-2 gap-1 bg-white dark:bg-slate-900 p-1 rounded-lg border border-slate-205/60 dark:border-slate-800">
                        <button
                          id="mode-auto-btn"
                          type="button"
                          onClick={() => setIsAutoMode(true)}
                          className={`py-1 text-[10px] font-extrabold rounded-md cursor-pointer transition-all ${
                            isAutoMode 
                              ? "bg-slate-50 dark:bg-slate-950 text-burgundy-500 font-bold"
                              : "text-slate-450 hover:text-slate-700"
                          }`}
                        >
                          ავტომატური
                        </button>
                        <button
                          id="mode-manual-btn"
                          type="button"
                          onClick={() => setIsAutoMode(false)}
                          className={`py-1 text-[10px] font-extrabold rounded-md cursor-pointer transition-all ${
                            !isAutoMode 
                              ? "bg-slate-50 dark:bg-slate-950 text-burgundy-500 font-bold"
                              : "text-slate-450 hover:text-slate-705"
                          }`}
                        >
                          მექანიკური
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                <button
                  id="launch-quiz-button"
                  disabled={!selectedFileId}
                  onClick={handleLaunchSingleQuiz}
                  className="w-full py-3.5 px-4 bg-burgundy-500 hover:bg-burgundy-600 dark:bg-burgundy-600 dark:hover:bg-burgundy-500 disabled:opacity-50 disabled:cursor-not-allowed font-extrabold text-white text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-sm transition-all uppercase tracking-wider cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  ტესტირების დაწყება
                </button>
              </div>

            </div>
          )}
        </div>
      )}

      {/* 🧬 2. EXAM SIMULATOR (MIXED) VIEW */}
      {activeTab === "multi" && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200/70 dark:border-slate-800/85 rounded-2xl p-6 space-y-6 shadow-sm">
          
          {uploadedFiles.length === 0 ? (
            <div className="p-12 text-center text-slate-400 dark:text-slate-500 border border-dashed border-slate-100 dark:border-slate-800 rounded-xl space-y-3">
              <Filter className="w-8 h-8 mx-auto text-slate-300" />
              <p className="text-xs font-sans font-medium">სიმულატორის დასაწყებად გთხოვთ ჯერ ატვირთოთ საგამოცდო .TXT ფაილები ზედა ველში.</p>
            </div>
          ) : (
            <div className="space-y-6">
              
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-100 dark:border-slate-850 pb-4">
                <div>
                  <h5 className="text-xs font-black uppercase text-slate-800 dark:text-slate-200 tracking-wider">
                    ინტელექტუალური საგამოცდო მიქსერი და ფაილები
                  </h5>
                  <p className="text-[11px] text-slate-450 dark:text-slate-400 mt-1">
                    მიუთითეთ თითოეული სამედიცინო მიმართულებიდან (ატვირთული ფაილიდან) გამოსაყენებელი კითხვების რაოდენობა.
                  </p>
                </div>

                {/* Fast presets */}
                <div className="flex gap-1.5 flex-wrap items-center bg-slate-50 dark:bg-slate-950 p-1.5 rounded-xl border border-slate-100 dark:border-slate-800 shrink-0">
                  <span className="text-[9px] font-extrabold uppercase text-slate-400 px-1.5">პაკეტები:</span>
                  <button
                    id="ratio-10-btn"
                    onClick={() => loadPresetQuotas(0.1)}
                    className="px-2.5 py-1 text-[10px] font-bold rounded-lg bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-150 dark:border-slate-800 hover:text-burgundy-500 hover:border-burgundy-500 cursor-pointer transition-all text-center"
                  >
                    10% ბაზიდან
                  </button>
                  <button
                    id="ratio-30-btn"
                    onClick={() => loadPresetQuotas(0.3)}
                    className="px-2.5 py-1 text-[10px] font-bold rounded-lg bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-150 dark:border-slate-800 hover:text-burgundy-500 hover:border-burgundy-500 cursor-pointer transition-all text-center"
                  >
                    30% ბაზიდან
                  </button>
                  <button
                    id="ratio-50-btn"
                    onClick={() => loadPresetQuotas(0.5)}
                    className="px-2.5 py-1 text-[10px] font-bold rounded-lg bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-150 dark:border-slate-800 hover:text-burgundy-500 hover:border-burgundy-500 cursor-pointer transition-all text-center"
                  >
                    50% ბაზიდან
                  </button>
                </div>
              </div>

              {/* Uploaded files list with direct Quota and Deletion triggers inside Exam view */}
              <div className="space-y-2.5 max-h-[350px] overflow-y-auto pr-1">
                {uploadedFiles.map(file => (
                  <div 
                    key={file.id} 
                    className="flex items-center justify-between p-3 border border-slate-100 dark:border-slate-850 hover:border-slate-200 dark:hover:border-slate-800 rounded-xl bg-slate-50/50 dark:bg-slate-950/20 transition-all gap-3"
                  >
                    <div className="flex items-center gap-2.5 min-w-0 flex-1">
                      <FileText className="w-4 h-4 text-burgundy-500 shrink-0" />
                      <div className="min-w-0">
                        <span className="text-xs font-bold text-slate-800 dark:text-slate-100 block truncate" title={file.name}>
                          {file.name}
                        </span>
                        <span className="text-[10px] text-slate-400 block font-sans">
                          ანონიმიზებული &bull; {file.totalQuestions} კითხვა
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3 shrink-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] text-slate-400 font-bold font-sans">კვოტა:</span>
                        <input
                          id={`quota-input-${file.id}`}
                          type="number"
                          min="0"
                          max={file.questions.length}
                          value={multiQuotas[file.id] || ""}
                          placeholder={`მაგ. 20`}
                          onChange={e => handleSetMultiQuota(file.id, e.target.value)}
                          className="w-16 sm:w-20 px-2 py-1.5 bg-white dark:bg-slate-950 border border-slate-205 dark:border-slate-800 text-xs font-bold text-slate-800 dark:text-slate-150 rounded-lg text-center focus:outline-none focus:border-burgundy-500"
                        />
                      </div>

                      {/* 🗑️ Trash deletes file right from the simulator view per user request */}
                      <button
                        id={`delete-file-exam-${file.id}`}
                        onClick={() => {
                          onDeleteFile(file.id);
                          if (selectedFileId === file.id) {
                            setSelectedFileId("");
                          }
                        }}
                        className="p-2 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-500/10 dark:hover:bg-rose-500/15 transition-all cursor-pointer"
                        title="ბაზის მთლიანად წაშლა"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {multiFileErrors && (
                <div id="multi-file-error-alert" className="p-3.5 bg-rose-500/10 border border-rose-500/25 text-rose-500 text-xs rounded-xl flex items-start gap-2 animate-fade-in font-sans">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{multiFileErrors}</span>
                </div>
              )}

              {/* Settings & launch row */}
              <div className="flex justify-between items-center border-t border-slate-100 dark:border-slate-850 pt-4 flex-wrap gap-4">
                <div className="flex gap-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      id="multi-shuffle-opts-toggle"
                      type="checkbox"
                      checked={shuffleOpts}
                      onChange={() => setShuffleOpts(!shuffleOpts)}
                      className="w-4 h-4 accent-burgundy-500 cursor-pointer"
                    />
                    <span className="text-[11px] font-bold text-slate-600 dark:text-slate-300">პასუხების არევა</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isAutoMode}
                      onChange={() => setIsAutoMode(!isAutoMode)}
                      className="w-4 h-4 accent-burgundy-500 cursor-pointer"
                    />
                    <span className="text-[11px] font-bold text-slate-600 dark:text-slate-300">ავტო-გადასვლა</span>
                  </label>
                </div>
                
                <button
                  id="launch-multi-quiz-button"
                  onClick={handleLaunchMultiQuiz}
                  className="px-6 py-3 bg-burgundy-500 hover:bg-burgundy-600 dark:bg-burgundy-600 dark:hover:bg-burgundy-500 text-white text-xs font-black rounded-xl flex items-center gap-2 shadow-sm cursor-pointer transition-all uppercase tracking-wider"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  სიმულაციის დაწყება
                </button>
              </div>

            </div>
          )}
        </div>
      )}

      {/* 📁 3. HISTORICAL SAVED MISTAKE SETS VIEW */}
      {activeTab === "saved" && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200/70 dark:border-slate-800/85 rounded-2xl p-6 space-y-4 shadow-sm">
          <div className="flex items-start gap-2.5">
            <div className="p-2 bg-slate-50 dark:bg-slate-950 border border-slate-105 dark:border-slate-850 rounded-lg text-burgundy-500">
              <Check className="w-5 h-5" />
            </div>
            <div>
              <h5 className="text-xs font-black uppercase text-slate-850 dark:text-slate-200 font-sans tracking-wide">
                გასწორებული და შენახული შეცდომების ნაკრებები
              </h5>
              <p className="text-[11px] text-slate-400 mt-1">
                საგამოცდო სესიებში შენახული შეცდომების არქივი. ივარჯიშეთ ცალკე თქვენს ინდივიდუალურ შეცდომებზე ცოდნის გასამყარებლად.
              </p>
            </div>
          </div>

          {savedMistakes.length === 0 ? (
            <div className="p-10 text-center rounded-xl bg-slate-50 dark:bg-slate-950/40 text-slate-400 dark:text-slate-500 border border-dotted border-slate-200 dark:border-slate-800 text-xs font-sans">
              შენახული შეცდომების არქივი ცარიელია და ტესტებში ჯერ შეცდომები არ დაგიფიქსირებიათ.
            </div>
          ) : (
            <div className="space-y-2.5 mt-2">
              {savedMistakes.map(set => (
                <div 
                  key={set.id} 
                  className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-4 border border-slate-100 dark:border-slate-800/60 rounded-xl bg-slate-50/50 dark:bg-slate-950/20 gap-3 hover:border-burgundy-500/40 transition-all"
                >
                  <div className="min-w-0">
                    <h6 className="text-xs font-extrabold text-slate-800 dark:text-slate-100 font-sans truncate">
                      {set.name}
                    </h6>
                    <p className="text-[10px] text-slate-400 mt-0.5 font-sans">
                      ჩაწერილია: {set.timestamp} &bull; კითხვები: <strong className="text-slate-700 dark:text-slate-300 font-sans">{set.questions.length}</strong>
                    </p>
                  </div>

                  <div className="flex gap-2 w-full sm:w-auto shrink-0">
                    <button
                      id={`load-mistakes-${set.id}`}
                      onClick={() => onLoadSavedMistakes(set)}
                      className="flex-1 sm:flex-initial px-4 py-1.5 rounded-lg bg-burgundy-500/10 text-burgundy-500 dark:text-burgundy-400 hover:bg-burgundy-500 hover:text-white transition-all text-[11px] font-bold cursor-pointer"
                    >
                      გავლა ახლავე
                    </button>
                    <button
                      id={`delete-mistakes-${set.id}`}
                      onClick={() => onDeleteSavedMistakes(set.id)}
                      className="px-2.5 py-1.5 rounded-lg bg-rose-500/10 text-rose-500 hover:bg-rose-500 hover:text-white transition-all text-[11px] font-bold cursor-pointer"
                    >
                      წაშლა
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

    </div>
  );
}
