import { useState, useEffect } from "react";
import { Sun, Moon } from "lucide-react";

export default function ThemeToggle() {
  const [isDark, setIsDark] = useState<boolean>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("theme");
      if (saved) return saved === "dark";
      // Fallback: Default to dark theme for safe nighttime medical cramming
      return true;
    }
    return true;
  });

  useEffect(() => {
    const root = window.document.documentElement;
    if (isDark) {
      root.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      root.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  }, [isDark]);

  return (
    <button
      id="theme-toggle-btn"
      onClick={() => setIsDark(!isDark)}
      className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-burgundy-500 dark:hover:text-burgundy-400 transition-all flex items-center justify-center cursor-pointer shadow-sm active:scale-95"
      title={isDark ? "დღის რეჟიმი" : "ღამის რეჟიმი"}
    >
      {isDark ? <Sun className="w-5 h-5 animate-pulse" /> : <Moon className="w-5 h-5" />}
    </button>
  );
}
