export interface Question {
  id: string;
  text: string;
  correctAnswers: string[];
  incorrectAnswers: string[];
  // Transformed list of all options after shuffle
  options: string[];
  // Original correct option text (to identify correctness regardless of shuffle)
  correctOptionText: string;
  // Source filename it came from
  sourceFile: string;
}

export interface QuizSession {
  questions: Question[];
  currentQuestionIndex: number;
  userAnswers: { [questionId: string]: string }; // selected answer text
  flaggedQuestionIds: { [questionId: string]: boolean };
  // Track individual mistakes made in the active session
  mistakes: Question[];
  // Mode parameters
  isAutoMode: boolean;
  isQuestionsShuffled: boolean;
  isOptionsShuffled: boolean;
  // State for sub-modes
  isReviewingMistakes: boolean;
  isReviewingFlags: boolean;
  // Paused position to return from review mode
  pausedIndex: number;
  // Original quiz context (holds actual full list before entering temporary mistake filter)
  originalQuestions: Question[];
}

export interface UploadedFile {
  id: string;
  name: string;
  totalQuestions: number;
  questions: Question[];
  timestamp: string;
}

export interface SavedMistakeSet {
  id: string;
  name: string;
  sourceFile: string;
  questions: Question[];
  timestamp: string;
  totalErrorsCount: number;
  correctedCount: number;
}
