import { useState, useEffect } from "react";
import { Sparkles, Brain, Code, FileText, CheckCircle2 } from "lucide-react";

import { Question, QuizSession, UploadedFile, SavedMistakeSet } from "./types";
import { CARDIOLOGY_RAW, PHARMACOLOGY_RAW, NEUROLOGY_RAW } from "./defaultQuestions";
import { parseQuestionsText, prepareQuestions } from "./utils";

import ThemeToggle from "./components/ThemeToggle";
import ClockWarning from "./components/ClockWarning";
import FileAnalyzer from "./components/FileAnalyzer";
import ActiveTest from "./components/ActiveTest";
import ExamResults from "./components/ExamResults";

export default function App() {
  // Application Modes: "setup" | "quiz" | "results"
  const [appMode, setAppMode] = useState<"setup" | "quiz" | "results">("setup");

  // State arrays
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [savedMistakes, setSavedMistakes] = useState<SavedMistakeSet[]>([]);
  
  // Active state controller
  const [session, setSession] = useState<QuizSession | null>(null);

  // Auto-load built-in Georgian medical sample catalogs on first launch
  const preloadDefaultFiles = () => {
    // Only preload if not already loaded to prevent duplicate spam
    const hasCardio = uploadedFiles.some(f => f.name === "კარდიოლოგიის_ბაზა_(სადემონსტრაციო).txt");
    if (hasCardio) return;

    const parsedCardio = parseQuestionsText(CARDIOLOGY_RAW, "კარდიოლოგიის_ბაზა_(სადემონსტრაციო).txt");
    const parsedPharma = parseQuestionsText(PHARMACOLOGY_RAW, "ფარმაკოლოგიის_ბაზა_(სადემონსტრაციო).txt");
    const parsedNeuro = parseQuestionsText(NEUROLOGY_RAW, "ნევროლოგიის_ბაზა_(სადემონსტრაციო).txt");

    const preloaded: UploadedFile[] = [
      {
        id: "pre-cardio",
        name: "კარდიოლოგიის_ბაზა_(სადემონსტრაციო).txt",
        totalQuestions: parsedCardio.length,
        questions: parsedCardio,
        timestamp: "სისტემური",
      },
      {
        id: "pre-pharma",
        name: "ფარმაკოლოგიის_ბაზა_(სადემონსტრაციო).txt",
        totalQuestions: parsedPharma.length,
        questions: parsedPharma,
        timestamp: "სისტემური",
      },
      {
        id: "pre-neuro",
        name: "ნევროლოგიის_ბაზა_(სადემონსტრაციო).txt",
        totalQuestions: parsedNeuro.length,
        questions: parsedNeuro,
        timestamp: "სისტემური",
      },
    ];

    setUploadedFiles(prev => [...prev, ...preloaded]);
  };

  // Perform self-initialization of preloaded databases for friendly start
  useEffect(() => {
    preloadDefaultFiles();
    
    // Retrieve past saved mistakes from local storage
    const savedLocal = localStorage.getItem("saved_mistakes_v1");
    if (savedLocal) {
      try {
        setSavedMistakes(JSON.parse(savedLocal));
      } catch (err) {
        console.error("Failed to restore mistakes from local disk cache", err);
      }
    }
  }, []);

  // Sync saved mistakes back to local Storage
  const handleUpdateSavedMistakes = (updated: SavedMistakeSet[]) => {
    setSavedMistakes(updated);
    localStorage.setItem("saved_mistakes_v1", JSON.stringify(updated));
  };

  // Handle addition of new custom uploaded text files
  const handleAddFiles = (newFiles: UploadedFile[]) => {
    setUploadedFiles(prev => [...prev, ...newFiles]);
  };

  const handleDeleteFile = (id: string) => {
    setUploadedFiles(prev => prev.filter(f => f.id !== id));
  };

  // Turn on active quiz evaluation
  const handleStartQuiz = (
    questions: Question[],
    isAutoMode: boolean,
    isQuestsShuffled: boolean,
    isOptsShuffled: boolean,
    initIndex: number = 0
  ) => {
    setSession({
      questions,
      currentQuestionIndex: initIndex,
      userAnswers: {},
      flaggedQuestionIds: {},
      mistakes: [],
      isAutoMode,
      isQuestionsShuffled: isQuestsShuffled,
      isOptionsShuffled: isOptsShuffled,
      isReviewingMistakes: false,
      isReviewingFlags: false,
      pausedIndex: 0,
      originalQuestions: [...questions]
    });
    setAppMode("quiz");
  };

  // Handle recording answers in real-time
  const handleAnswerQuestion = (questionId: string, answerText: string) => {
    if (!session) return;

    const currentQuestion = session.questions[session.currentQuestionIndex];
    const isCorrect = answerText === currentQuestion.correctOptionText;

    // Expand userAnswers list
    const updatedAnswers = {
      ...session.userAnswers,
      [questionId]: answerText
    };

    // Update active mistakes pile (remove if corrected, append if incorrect)
    let updatedMistakes = [...session.mistakes];
    if (!isCorrect) {
      // Avoid duplicating the question if they answered wrong, but ensure it's recorded
      if (!updatedMistakes.some(m => m.id === currentQuestion.id)) {
        updatedMistakes.push(currentQuestion);
      }
    }

    setSession(prev => {
      if (!prev) return null;
      return {
        ...prev,
        userAnswers: updatedAnswers,
        mistakes: updatedMistakes,
      };
    });
  };

  // Support Flag / Bookmarking trigger
  const handleToggleFlag = (questionId: string) => {
    if (!session) return;
    const isFlagged = !session.flaggedQuestionIds[questionId];
    setSession(prev => {
      if (!prev) return null;
      return {
        ...prev,
        flaggedQuestionIds: {
          ...prev.flaggedQuestionIds,
          [questionId]: isFlagged,
        }
      };
    });
  };

  const handleGoToNextQuestion = () => {
    setSession(prev => {
      if (!prev) return null;
      return {
        ...prev,
        currentQuestionIndex: prev.currentQuestionIndex + 1
      };
    });
  };

  const handleGoToQuestionIndex = (index: number) => {
    setSession(prev => {
      if (!prev) return null;
      return {
        ...prev,
        currentQuestionIndex: index
      };
    });
  };

  // Pauses current run and closes screen
  const handlePauseQuiz = () => {
    setSession(null);
    setAppMode("setup");
  };

  // Trigger rapid mistakes correcting subloop ("შეცდომების გავლა ახლავე")
  const handleStartMistakesSubMode = () => {
    if (!session || session.mistakes.length === 0) return;

    // Preserving the currently active question index to restore later
    const previousIndex = session.currentQuestionIndex;

    // Double shuffle the mistakes payload
    const shuffledMistakes = prepareQuestions(session.mistakes, session.isQuestionsShuffled, session.isOptionsShuffled);

    // Create fresh answers mapping, leaving previously flagged questions bookmarked
    const emptySubAnswers: { [key: string]: string } = {};

    setSession(prev => {
      if (!prev) return null;
      return {
        ...prev,
        questions: shuffledMistakes,
        currentQuestionIndex: 0,
        userAnswers: emptySubAnswers,
        isReviewingMistakes: true,
        pausedIndex: previousIndex,
      };
    });
  };

  const handleFinishQuiz = () => {
    if (!session) return;

    // If reviewing current mistakes sub-mode is complete, return to primary stream
    if (session.isReviewingMistakes) {
      setSession(prev => {
        if (!prev) return null;
        return {
          ...prev,
          questions: prev.originalQuestions,
          currentQuestionIndex: prev.pausedIndex, // restores position
          userAnswers: prev.userAnswers, // retains initial answers
          isReviewingMistakes: false,
          mistakes: [], // clears current session mistakes pile upon correction
        };
      });
    } else {
      setAppMode("results");
    }
  };

  // Restart directly using mistakes
  const handleRestartWithMistakes = () => {
    if (!session || session.mistakes.length === 0) return;
    const shuffledMistakes = prepareQuestions(session.mistakes, session.isQuestionsShuffled, session.isOptionsShuffled);
    handleStartQuiz(shuffledMistakes, session.isAutoMode, session.isQuestionsShuffled, session.isOptionsShuffled);
  };

  // Restart directly using flags
  const handleRestartWithFlags = () => {
    if (!session) return;
    const flaggedList = session.originalQuestions.filter(q => session.flaggedQuestionIds[q.id]);
    if (flaggedList.length === 0) return;
    const shuffledFlags = prepareQuestions(flaggedList, session.isQuestionsShuffled, session.isOptionsShuffled);
    handleStartQuiz(shuffledFlags, session.isAutoMode, session.isQuestionsShuffled, session.isOptionsShuffled);
  };

  // Record mistakes file archive
  const handleSaveMistakes = (name: string, questions: Question[]) => {
    const freshSet: SavedMistakeSet = {
      id: Math.random().toString(36).substring(2, 11) + "-" + Date.now(),
      name,
      sourceFile: questions[0]?.sourceFile || "Composite",
      questions,
      timestamp: new Date().toLocaleDateString("ka-GE", { day: "numeric", month: "long" }) + " " + new Date().toLocaleTimeString("ka-GE", { hour: "2-digit", minute: "2-digit" }),
      totalErrorsCount: questions.length,
      correctedCount: 0,
    };

    handleUpdateSavedMistakes([freshSet, ...savedMistakes]);
  };

  const handleDeleteSavedMistakes = (id: string) => {
    const updated = savedMistakes.filter(s => s.id !== id);
    handleUpdateSavedMistakes(updated);
  };

  // Boot standard saved mistakes set as a study course
  const handleLoadSavedMistakes = (set: SavedMistakeSet) => {
    const prepared = prepareQuestions(set.questions, true, true);
    handleStartQuiz(prepared, true, true, true);
  };

  const handleResetToSetup = () => {
    setSession(null);
    setAppMode("setup");
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-300">
      
      {/* Dynamic Upper Top Navigation with clean theme-adaptive background */}
      <header className="sticky top-0 z-50 bg-white/80 dark:bg-slate-950/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800/80 shadow-[0_1px_3px_rgba(0,0,0,0.01)]">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          
          <div className="flex items-center gap-3.5">
            <div className="p-2.5 rounded-xl bg-burgundy-500 text-white shadow-md shadow-burgundy-500/10 hover:scale-105 transition-transform">
              <Brain className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[9px] font-black uppercase tracking-wider bg-burgundy-100 dark:bg-burgundy-200/10 text-burgundy-600 dark:text-burgundy-400 px-2.5 py-1 rounded-md leading-none font-mono">
                  SUPREME EDITION
                </span>
              </div>
              <h1 className="text-md sm:text-lg font-extrabold tracking-tight text-slate-850 dark:text-slate-100 font-sans mt-0.5 gradient-title">
                სამედიცინო საგამოცდო პლატფორმა
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <ThemeToggle />
          </div>
        </div>
      </header>

      {/* Main Structural Body View */}
      <main className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        
        {/* Bedtime analyzer (past midnight alert system) */}
        {appMode === "setup" && <ClockWarning />}

        {appMode === "setup" && (
          <FileAnalyzer
            uploadedFiles={uploadedFiles}
            onAddFiles={handleAddFiles}
            onDeleteFile={handleDeleteFile}
            onStartQuiz={handleStartQuiz}
            savedMistakes={savedMistakes}
            onLoadSavedMistakes={handleLoadSavedMistakes}
            onDeleteSavedMistakes={handleDeleteSavedMistakes}
            preloadedDefaultFiles={preloadDefaultFiles}
          />
        )}

        {appMode === "quiz" && session && (
          <ActiveTest
            session={session}
            onAnswerQuestion={handleAnswerQuestion}
            onToggleFlag={handleToggleFlag}
            onGoToNextQuestion={handleGoToNextQuestion}
            onGoToQuestionIndex={handleGoToQuestionIndex}
            onPauseQuiz={handlePauseQuiz}
            onStartMistakesSubMode={handleStartMistakesSubMode}
            onFinishQuiz={handleFinishQuiz}
          />
        )}

        {appMode === "results" && session && (
          <ExamResults
            questions={session.originalQuestions}
            userAnswers={session.userAnswers}
            flaggedQuestionIds={session.flaggedQuestionIds}
            onRestartWithMistakes={handleRestartWithMistakes}
            onRestartWithFlags={handleRestartWithFlags}
            onSaveMistakes={handleSaveMistakes}
            onResetToSetup={handleResetToSetup}
          />
        )}

      </main>

      {/* Humble Footer boundaries */}
      <footer className="mt-16 border-t border-slate-200/60 dark:border-slate-900 py-8 text-center text-xs text-slate-400 dark:text-slate-600 space-y-2">
        <p className="font-sans">
          შემუშავებულია სპეციალურად მედიცინის სტუდენტებისა და რეზიდენტებისთვის საგამოცდო ბარიერების სწრაფი დაძლევისთვის
        </p>
        <p className="font-mono text-[10px]">
          თბილისი &bull; 2026
        </p>
      </footer>

    </div>
  );
}
